﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelismDemo
{
    public static class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(System.Environment.ProcessorCount);
            string[] words = { "a", "b", "c", "d", "e", "n" };
            System.Diagnostics.Stopwatch _watch = new System.Diagnostics.Stopwatch();
            _watch.Start();
           List<string> encryptedWords= words.AsParallel().Select(
               (string item) => { return Encrypt(item); }).ToList<string>();
            _watch.Stop();
            Console.WriteLine(_watch.ElapsedMilliseconds);

        }

        public static string Encrypt(string word)
        {
            System.Threading.Thread.Sleep(1000);
            string encryptedWord = word.ToUpper();
            return encryptedWord;
        }
    }
}
