﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionProgramming
{
   public static  class CustomExtensionMethods
    {
        
        public static void Test(this string item, int value) { }
        public static IEnumerable<T> Query<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            List<T> _resultList = new List<T>();
            foreach (T item in source)
            {
                if (predicate.Invoke(item))
                {
                    _resultList.Add(item);
                }

            }
            return _resultList;
        }
        public static void PrintItemsOnConsole<T>(this IEnumerable<T> items)
        {
            foreach (T item in items)
            {
                Console.WriteLine(item);
            }
        }
    }
}
