﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionProgramming
{
   public  class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "Arun", "Venu", "Bnil", "Abhi", "Ayush" };
           
            
            Func<string, bool> _filterCondition1 = StartsWithClosure("A");
            
            
            //Fluent Interface Pattern (Method Chaining)
            names.Query(_filterCondition1).PrintItemsOnConsole();
           IEnumerable<string> result= CustomExtensionMethods.Query(names, _filterCondition1);
            CustomExtensionMethods.PrintItemsOnConsole(result);

            Func<string, bool> _filterCondition2 = StartsWithClosure("V");
            names.Query(_filterCondition1).PrintItemsOnConsole();
            Func<string, bool> _filterCondition3 = StartsWithClosure("D");
            names.Query(_filterCondition1).PrintItemsOnConsole();
            int[] numbers = new int[] { 3, 5, 8, 9, 4 };

            numbers.Query((int item) => { return item % 2 == 0; });
            List<string> nameList = names.ToList();
            nameList.Query(_filterCondition1).PrintItemsOnConsole();
            nameList.PrintItemsOnConsole();

        }

      //High Order Function
        static Func<string,bool> StartsWithClosure(string letter)
        {
            Func<string, bool> _filterCondition = (string item) => { return item.StartsWith(letter); };
            return _filterCondition;
        }

        static bool IsStringStartsWithA(string item)
        {
            string letter= "A";
            return item.StartsWith(letter);
        }
        static bool IsStringStartsWithV(string item)
        {
            return item.StartsWith("V");
        }
        //Pure function 
      
    }
}
