﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingBasics
{
  public   class MutexDemo
    {
        static Mutex _handle;//wait(red)/Signal(green)
        static void UseATM()
        {
            Console.WriteLine($" {Thread.CurrentThread.Name} waiting in queue to Use Atm");
            _handle.WaitOne();//Block the thread - if handle is in wait state
            //Critical Section 
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine($"{Thread.CurrentThread.Name} Using Atm");
                Thread.Sleep(1000);
            }

            _handle.ReleaseMutex();//Set handler state -> signal/free/green
        }
        static void Security()
        {
            _handle = new Mutex(true);
            
         }

        static void Mutex_Main()
        {
            Security();
            new Thread(UseATM) { Name = "Arun" }.Start();
            new Thread(UseATM) { Name = "Ajay" }.Start();
            new Thread(UseATM) { Name = "Anil" }.Start();
            new Thread(UseATM) { Name = "Anirud" }.Start();
            Console.WriteLine("Press Any Key to Release Mutex");
            Console.ReadLine();
            _handle.ReleaseMutex();

        }
    }
}
