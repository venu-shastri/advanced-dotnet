﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadingBasics
{
    //[System.Runtime.Remoting.Contexts.Synchronization]
    public class DBDriver //:System.ContextBoundObject
    {
        public static readonly DBDriver Instance = new DBDriver();
        private DBDriver() {

            Console.WriteLine("DBDriver Instance Created");
        }

        //[System.Runtime.CompilerServices.MethodImpl(
        //    System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void Create() {
            System.Threading.Monitor.Enter(this);
            try
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine($"Create .....{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                    System.Threading.Thread.Sleep(1000);
                    if (i == 4) { return; }
                }
            }
            finally
            {
                System.Threading.Monitor.Exit(this);
            }


        }
        //[System.Runtime.CompilerServices.MethodImpl(
        //  System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void Delete() {
            System.Threading.Monitor.Enter(this);
            try
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine($"Delete .....{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                    System.Threading.Thread.Sleep(1000);
                }
            }
            finally
            {
                System.Threading.Monitor.Exit(this);
            }

        }

        //[System.Runtime.CompilerServices.MethodImpl(
        //  System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void Update()
        {
            lock (this)
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine($"Update .....{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                    System.Threading.Thread.Sleep(1000);
                }

            }
        }

        //[System.Runtime.CompilerServices.MethodImpl(
        //  System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void Retrieve()
        {
            System.Threading.Monitor.Enter(this);
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Retrieve .....{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                System.Threading.Thread.Sleep(1000);
            }
            System.Threading.Monitor.Exit(this);
        }
        //[System.Runtime.CompilerServices.MethodImpl(
        //  System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void RetrieveByFiletr()
        {
            System.Threading.Monitor.Enter(this);
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Retrieve By Fil .....{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                System.Threading.Thread.Sleep(1000);
            }
            System.Threading.Monitor.Exit(this);
        }



    }
}
