﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    
    public class Employee
    {
        [CLRObjectPersisterFxLib.XMLElement]
        [System.Xml.Serialization.XmlAttribute]
         public string Eid { get; set; }

        [CLRObjectPersisterFxLib.XMLAttribute]
        public string Name { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee _empObject = new Employee() { Eid = "Emp100", Name = "Tom" };

            //CLRObjectPersisterFxLib.ObjectPersister _persister = 
            //      new CLRObjectPersisterFxLib.ObjectPersister(typeof(Employee));
            //  _persister.Persist(_empObject,CLRObjectPersisterFxLib.FormatType.XML);
            WriteToXml(_empObject);
            
        }


        static void WriteToXml(object source)
        {

            System.Xml.Serialization.XmlSerializer _serializer = new System.Xml.Serialization.XmlSerializer(source.GetType());
            System.IO.StreamWriter _writer = new System.IO.StreamWriter("..//..//employee.xml");
            _serializer.Serialize(_writer.BaseStream, source);
            _writer.Flush();
            _writer.Close();

        }
    }
}
