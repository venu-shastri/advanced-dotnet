﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelismDemo
{
    public static class Program
    {
        static void Main_old(string[] args)
        {
            //System.Collections;
            //System.Collections.Generic
            System.Collections.Concurrent.ConcurrentBag<string> _resultList = new System.Collections.Concurrent.ConcurrentBag<string>();
            Console.WriteLine(System.Environment.ProcessorCount);
            string[] words = { "a", "b", "c", "d", "e", "n" };
            System.Diagnostics.Stopwatch _watch = new System.Diagnostics.Stopwatch();
            _watch.Start();
            //words.AsParallel().WithDegreeOfParallelism(2).Select(
            System.Collections.Concurrent.Partitioner.
               Create(words, true).
               AsParallel().
               WithDegreeOfParallelism(2).
               Select((string item) => { return Encrypt(item); }).
               ForAll((item) =>
               {
                   string result = $"{item} processed by {System.Threading.Thread.CurrentThread.ManagedThreadId}";
                   _resultList.Add(result);
               });
            _watch.Stop();
            Console.WriteLine(_watch.ElapsedMilliseconds);
            var resultArray = _resultList.ToArray();
            //for (int i = 0; i < resultArray.Length; i++)
            //{
            //    PrintToConsole(resultArray[i]);

            //}
            //Parallel.For(0, resultArray.Length, (index) =>
            //{
            //    PrintToConsole(resultArray[index]);
            //});

            Parallel.ForEach(_resultList, (item) => { PrintToConsole(item); });

        }

        public static void PrintToConsole(string item)
        {
            Console.WriteLine($"Printing On Cossole By {System.Threading.Thread.CurrentThread.ManagedThreadId} - {item}");
        }
        public static string Encrypt(string word)
        {
            if (word == "b") { System.Threading.Thread.Sleep(10000); }
            System.Threading.Thread.Sleep(1000);
            string encryptedWord = word.ToUpper();


            return encryptedWord;
        }
        public static void Main()
        {
            //while (true)
            //{
            //    Console.WriteLine("Press Any Key to Change State");

            //    ObserverPattern.SetState(Console.ReadLine());
            //}

          

                Parallel.Invoke(Task1, Task2, Task3);
          
                

            
        }

        static void Task1() { 
        for(int i = 0; i < 2; i++)
            {
                Console.WriteLine($" Task 1 .isBackgroud {System.Threading.Thread.CurrentThread.IsBackground}");

            }
        }
        static void Task2() {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($" Task 2 .isBackgroud {System.Threading.Thread.CurrentThread.IsBackground}");

            }
        }
        static void Task3() {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($" Task 3 .isBackgroud {System.Threading.Thread.CurrentThread.IsBackground}");

            }
        }
    }

}
