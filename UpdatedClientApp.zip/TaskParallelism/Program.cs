﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskParallelism
{
    class Program
    {
        static void Main(string[] args)
        {
            Task _mainTask = new Task(ApplyForLoan);
            _mainTask.Start();
            try
            {
                _mainTask.Wait();
            }
            catch(AggregateException ex)
            {
                foreach(Exception e in ex.Flatten().InnerExceptions)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        static void Test_Tasks()
        {
            Task _asyncTask = new Task(() => {

                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine("async Tsk1");
                    if (i == 5) { throw new Exception("Async Task Exception"); }
                    System.Threading.Thread.Sleep(1000);
                }
            });

            Task<string> _newAsyncTask = new Task<string>(() => {
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine("New Async Task ");
                    if (i == 8) { throw new Exception("NewAsync Task Exception"); }
                    System.Threading.Thread.Sleep(1000);
                }
                return "Done!";
            });
            _asyncTask.Start();
            _newAsyncTask.Start();


            try
            {
                Task.WaitAll(_asyncTask, _newAsyncTask);
            }
            catch (AggregateException ex)
            {
                AggregateException collective = ex.Flatten();
                foreach (Exception exception in collective.InnerExceptions)
                {
                    Console.WriteLine(exception.Message);
                }

            }

            if (!_newAsyncTask.IsFaulted)
            {
                Console.WriteLine(_newAsyncTask.Result);
            }

        }
        static void ApplyForLoan()
        {
            Console.WriteLine("Loan process Begin....");
            new Task(VerifyCBIL,TaskCreationOptions.AttachedToParent).Start();
            new Task(VeryPropertyDocs,TaskCreationOptions.AttachedToParent).Start();
            new Task(VerifyTaxReturns,TaskCreationOptions.AttachedToParent).Start();


        }
        static void VerifyCBIL() {

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("VerifyCBIL");
                if (i == 8) { throw new Exception("VerifyCBIL Task Exception"); }
                System.Threading.Thread.Sleep(1000);
            }
        }

        static void VeryPropertyDocs() {

            for (int i = 0; i <5; i++)
            {
                Console.WriteLine("VeryPropertyDocs");
                 if (i == 3) { throw new Exception("VeryPropertyDocs Task Exception"); }
                System.Threading.Thread.Sleep(1000);
            }
        }

        static void VerifyTaxReturns() {

            for (int i = 0; i < 15; i++)
            {
                Console.WriteLine("VerifyTaxReturns");
                 if (i == 10) { throw new Exception("VerifyTaxReturns Task Exception"); }
                System.Threading.Thread.Sleep(1000);
            }
        }

    }
}
