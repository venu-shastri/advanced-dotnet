﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace Installer
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isNewOne;
            Mutex _mutex = new Mutex(true, "ABC", out isNewOne);
           
            if (isNewOne)
            {
                for (int i = 0; i < 100; i++)
                {
                    Console.WriteLine("Installing...........");
                    System.Threading.Thread.Sleep(1000);
                }
            }
            else
            {
                Console.WriteLine("Another Instance of Installer in Execution......");
                Thread.Sleep(1000);
                System.Environment.Exit(0);
            }
        }
    }
}
