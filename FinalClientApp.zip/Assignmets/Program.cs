﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignmets
{
    class CustomIntegerList
    {
        int[] items;
        int index=-1;
        public CustomIntegerList() { items = new int[3]; }
        public CustomIntegerList(int capacity)
        {
            items=new int [capacity];

        }
        public void Add(int item)
        {
            if (index == items.Length)
            {
                int[] temp = new int[index + 10];

                items.CopyTo(temp, 0);
                items = temp;
            }
            index++;
            items[index] = item;
        }
        public int Get(int index)
        {
            return items[index];
        }
        //public int get_Item(int index)
        public int this[int index]
        {
            get
            {
                return items[index];
            }
        }
        public void Clear()
        {
            items = new int[10];
        }
    }

    class CustomObjectList
    {
        object[] items;
        int index = -1;
        public CustomObjectList() { items = new object[3]; }
        public CustomObjectList(int capacity)
        {
            items = new object[capacity];

        }
        public void Add(object item)
        {
            if (index == items.Length)
            {
                object[] temp = new object[index + 10];

                items.CopyTo(temp, 0);
                items = temp;
            }
            index++;
            items[index] = item;
        }
        public object Get(int index)
        {
            return items[index];
        }
        //public int get_Item(int index)
        public object this[int index]
        {
            get
            {
                return items[index];
            }
        }
        public void Clear()
        {
            items = new object[10];
        }
    }
    class Program
    {
        public static int  Div(int x,int y)
        {
            return x / y;
        }
        static void Main(string[] args)
        {

            CustomIntegerList _list = new CustomIntegerList();
            for(int i = 0; i < 20; i++)
            {
                _list.Add(i + 10);
            }
            int item = _list[12];//_list.get_Item(12);

            CustomObjectList _intList = new CustomObjectList();
            int x = 10;//stack - 4 
            _intList.Add(x);//heap - 12bytes
            _intList.Add(20);
            _intList.Add("30");
            _intList.Add("Thirty");

            int value = (int)_intList[3];//Explicit Cast -Unbox
                
            CustomObjectList _stringList = new CustomObjectList();
            _stringList.Add("10");
            _stringList.Add("20");
            _stringList.Add("30");






        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            
        }
    }
}
