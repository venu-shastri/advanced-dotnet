﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelismDemo
{
   public static class ObserverPattern
    {
        static string state;
        //static List<Action> _observers = new List<Action>();
        public static void SetState(string newState)
        {
          state = newState;
            //Task Parallelism
            
            Parallel.Invoke(ObserverOne, ObserverTwo, ObserverThree);
        }

        public static void  ObserverOne()
        {
            //Mail
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("Sending Mai.....");
                System.Threading.Thread.Sleep(1000);
            }

        }
        public static void  ObserverTwo()
        {
            for (int i = 0; i < 10; i++)
            {
                //Update Log
                Console.WriteLine("Updating Log .....");
                System.Threading.Thread.Sleep(1000);
            }
        }
        public static  void ObserverThree()
        {
            //Update SMS
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Sending Sms.....");
                System.Threading.Thread.Sleep(1000);
            }
        }

    }

    


}
