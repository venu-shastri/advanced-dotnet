﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicProgramming
{
    class PropertyBag:System.Dynamic.DynamicObject
    {
        Dictionary<string, object> _propertyStore = new Dictionary<string, object>();
        Dictionary<string, Action> _functionStore = new Dictionary<string, Action>();

        public PropertyBag()
        {
            _functionStore.Add("Dump", () =>{ this.DumpDictionary(); });
        }
        

        
        public override bool TrySetMember(SetMemberBinder binder, object value)
        {
            _propertyStore[binder.Name] = value;
            return true;
        }
        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            result = null;
            if (_propertyStore.ContainsKey(binder.Name))
            {
                result = _propertyStore[binder.Name];
                return true;
            }
            return false;
        }

        public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
        {
            result = null;
            if (_functionStore.ContainsKey(binder.Name))
            {
                _functionStore[binder.Name].Invoke();
               
                return true;
            }
            return false;
        }
        private void DumpDictionary()
        {
           foreach(KeyValuePair<string,object> keyValue in _propertyStore)
            {
                Console.WriteLine($"{keyValue.Key} => {keyValue.Value}");
            }
        }

        public void Clear()
        {

        }
    }

    public class CSVItem:DynamicObject
    {
        string[] _lineContent;
        public static List<string> headerContent = null;
        public void setContent(string[] lineContent)
        {
            this._lineContent = lineContent;
        }

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            result = null;
            int index = headerContent.IndexOf(binder.Name);
            if (index == -1)
            {
                return false;
            }
            result = _lineContent[index];
            return true;

        }

    }

    public class DictionaryCSVItem : DynamicObject
    {
        Dictionary<string, object> _lineContent = new Dictionary<string, object>();

        public void AddLineContent(string key ,object value)
        {
            _lineContent[key] = value;
        }
       
        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            result = null;
            
            if (_lineContent.ContainsKey(binder.Name))
            {
                result = _lineContent[binder.Name];
                return true;
            }

            return false;

        }

    }
    public class CSVContentReader
    {
        public IEnumerable<CSVItem> GetCSVData(string csvFile)
        {
            List<CSVItem> csvDataList = new List<CSVItem>();
            using (var reader = new StreamReader(csvFile))
            {
                var line = reader.ReadLine();
                CSVItem.headerContent = line.Split(',').ToList();
                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    var values = line.Split(',');
                    CSVItem obj = new CSVItem();
                    obj.setContent(values);
                    csvDataList.Add(obj);
                }
            }
            return csvDataList;
        }

        public IEnumerable<DictionaryCSVItem> GetCSVContent(string csvFile)
        {
            List<DictionaryCSVItem> csvDataList = new List<DictionaryCSVItem>();
            using (var reader = new StreamReader(csvFile))
            {
                var headerLineContent = reader.ReadLine().Split(',');
              
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    DictionaryCSVItem obj = new DictionaryCSVItem();
                    for(int i=0;i< headerLineContent.Length; i++)
                    {
                        obj.AddLineContent(headerLineContent[i], values[i]);
                    }
                    
                    csvDataList.Add(obj);
                }
            }
            return csvDataList;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            CSVContentReader _contentReader = new CSVContentReader();
           IEnumerable<DictionaryCSVItem> _items= _contentReader.GetCSVContent("..//..//Devices.csv");
            IEnumerable<dynamic> resultItems= _items.Where((dynamic item) => { return (string)item.Code == "F1" && Int32.Parse (item.Cost) > 1000; });
              foreach(dynamic item in resultItems)
            {
                Console.WriteLine($"{item.Id},{item.Name},{item.Cost},{item.Code}");
            }




            
        }
    }
}
