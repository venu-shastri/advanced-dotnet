﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCDemo
{

    public static class WaitHandles
    {
        public static System.Threading.AutoResetEvent _resourceAvailabilitySignal = new System.Threading.AutoResetEvent(false);
    }
    public enum ResourceState
    {
        FREE, BUSY
    }
    public class Resource {

        public static readonly Resource Instance = new Resource();
        public ResourceState State = ResourceState.FREE;

        public void UseResource()
        {
            Console.WriteLine("Resource Used By " + System.Threading.Thread.CurrentThread.ManagedThreadId);
        }

    }

    public class A : IDisposable
    {
        private bool disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects)
                }

                // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                // TODO: set large fields to null
                disposedValue = true;
            }
        }

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        ~A()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: false);
        }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
    //Object dispose Pattern
    class ManagedClass:IDisposable
    {
        bool isDisposed = false;
        public ManagedClass()
        {
            lock (WaitHandles._resourceAvailabilitySignal) {
                if (Resource.Instance.State == ResourceState.FREE)
                {
                    Resource.Instance.State = ResourceState.BUSY;
                    Console.WriteLine("Resource Owned By " + System.Threading.Thread.CurrentThread.ManagedThreadId);
                }
                else
                {
                    Console.WriteLine("Thread " + System.Threading.Thread.CurrentThread.ManagedThreadId + " Awaiting For Resource");
                    WaitHandles._resourceAvailabilitySignal.WaitOne();
                    Resource.Instance.State = ResourceState.BUSY;
                    Console.WriteLine("Resource Owned By " + System.Threading.Thread.CurrentThread.ManagedThreadId);
                }
            }
        }

        public void Task()
        {
            if (isDisposed)
            {
                throw new ObjectDisposedException("ManagedClass Object Disposed");
            }
            for(int i = 0; i < 10; i++)
            {
                Resource.Instance.UseResource();
                System.Threading.Thread.Sleep(1000);

            }
        }

        private  void ReleaseResource()
        {
           
            Resource.Instance.State = ResourceState.FREE;
            WaitHandles._resourceAvailabilitySignal.Set();

        }
        public virtual void Dispose(bool isDisposing)
        {
            if (!isDisposed)
            {
                if (isDisposing)
                {
                    Console.WriteLine("Resource Released By " + System.Threading.Thread.CurrentThread.ManagedThreadId + " via Dispose Method");
                     isDisposed = true;
                     GC.SuppressFinalize(this);
                }
            }
            ReleaseResource();

                

        }
        public void Dispose()
        {
            Dispose(true);
        }

        //private void Finalize(){}- MSIL
        ~ManagedClass()
        {
            Console.WriteLine("Resource Released By " + System.Threading.Thread.CurrentThread.ManagedThreadId + " via Finalize Method");
            Dispose(false);
            
        }
     
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            new System.Threading.Thread(Client1).Start();
            new System.Threading.Thread(Client2).Start();
        }
        static void Client1()
        {
            ManagedClass _obj = new ManagedClass ();
            _obj.Task();
            //_obj.Dispose();
            _obj = null;
            GC.Collect();
            //try
            //{
            //    _obj = new ManagedClass();
            //    _obj.Task();
            //    _obj.Dispose();
            //    _obj.Task();
                
            //}
            //catch
            //{
            //    _obj.Dispose();
            //}

            //finally
            //{
            //    if (_obj !=null && _obj is IDisposable)
            //    {
            //        _obj.Dispose();
            //    }
            //}
          
        }
        static void Client2()
        {
            using (ManagedClass _obj = new ManagedClass())
            {
                _obj.Task();
            }
            
            


        }
    }
}
