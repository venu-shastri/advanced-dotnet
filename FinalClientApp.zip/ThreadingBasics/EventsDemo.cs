﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace ThreadingBasics
{
    public class EventsDemo
    {
        static AutoResetEvent _handlea = new AutoResetEvent(false);
        static AutoResetEvent _handleb = new AutoResetEvent(false);
        static AutoResetEvent _handlec = new AutoResetEvent(false);
        static ManualResetEvent _brodcastHandler = new ManualResetEvent(false);
        public static void Task1() {
            _brodcastHandler.WaitOne(); 
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("Task1");
                Thread.Sleep(1000);
                if (i == 5)
                {
                    _handlea.Set();
                    
                }
            }
            
           
        }
        public static void Task2() {
            WaitHandle.WaitAll(new WaitHandle[] { _brodcastHandler,_handlea});
            
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Task2");
                Thread.Sleep(1000);
                if (i == 6) { _handleb.Set(); }
            }
            
        }
        public static void Task3() {
            _brodcastHandler.WaitOne();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Task3");
                Thread.Sleep(1000);
            }
            _handlec.Set();
        }

        public static void Main()
        {
            new Thread(Task1) { IsBackground = true }.Start();
            new Thread(Task2) { IsBackground = true }.Start();
            new Thread(Task3) { IsBackground = true }.Start();
            Thread.Sleep(200);
            _brodcastHandler.Set();
            WaitHandle.WaitAll(new WaitHandle[] { _handlea, _handleb, _handlec });
        }
    }
}
